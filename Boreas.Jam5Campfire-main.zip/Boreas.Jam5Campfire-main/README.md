# ![Boreas.Jam5Campfire](assets/MISSING_CAKE.PNG)

# Mystery of the Missing Cake

A very small mod made for the Outer Wilds 5th Mod Jam.

# Disclaimer
This mod is very rough around the edges, but just wanted to get a submission done.

# Requirements
This mod is an addon for New Horizons, so it requires that mod in order to function
This mod takes place in the Jam 5 System, so Mod Jam 5 by xen and SBtT is required for the mod to function
